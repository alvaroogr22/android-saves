package com.example.proyectosrecycledview

data class Course(val name: String, val subjects: List<Subject>)