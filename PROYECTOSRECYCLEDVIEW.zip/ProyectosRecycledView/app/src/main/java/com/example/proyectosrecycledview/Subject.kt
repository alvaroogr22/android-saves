package com.example.proyectosrecycledview

data class Subject(val name: String)