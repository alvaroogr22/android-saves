package com.proyectorecycled4

data class Subject(val name: String)