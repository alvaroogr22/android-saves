package com.proyectorecycled4

data class Trabajos(val name: String, val subjects: List<Subject>)